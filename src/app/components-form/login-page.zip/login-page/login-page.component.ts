import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
 
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent {

  constructor(private fb: FormBuilder, private http: HttpClient) { }

  loginForm = this.fb.group({
    userName: ['', Validators.required],
    password: ['', Validators.required],
    role: 'user'
  });

 

  submitLogin() {
    let body: any = {
      username: this.loginForm.value.userName,
      password: this.loginForm.value.password,
      role: this.loginForm.value.role,
    }
    let url = "";
    this.http.get(url, body).subscribe(res => {
      console.log(res, "response")
    })

    console.log(body, "body")
  }
}
